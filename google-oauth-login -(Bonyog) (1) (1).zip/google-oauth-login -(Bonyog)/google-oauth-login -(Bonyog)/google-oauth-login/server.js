require('dotenv').config();
const express = require('express');
const cookieParser = require('cookie-parser');
const { OAuth2Client } = require('google-auth-library');

const app = express();
const port = process.env.PORT || 3000;
const CLIENT_ID = process.env.GOOGLE_CLIENT_ID;
const client = new OAuth2Client(CLIENT_ID);

app.use(express.json());
app.use(cookieParser());
app.use(express.static('public')); // Serves the index.html and other static files

// POST endpoint to verify Google ID token sent from frontend
app.post('/api/auth/google', async (req, res) => {
  try {
    const { idToken } = req.body;
    if (!idToken) return res.status(400).json({ error: 'Missing idToken' });

    // Verify the token and parse user info
    const ticket = await client.verifyIdToken({
      idToken,
      audience: CLIENT_ID,
    });

    const payload = ticket.getPayload();
    const userEmail = payload.email;

    // Create a session cookie (optional: configure secure cookie options)
    res.cookie('session', JSON.stringify({ email: userEmail }), {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      maxAge: 24 * 60 * 60 * 1000, // 1 day
    });

    res.json({ success: true, email: userEmail });
  } catch (err) {
    console.error('Error verification error:', err);
    return res.status(401).json({ error: 'Invalid ID Token' });
  }
});

// POST endpoint to sign out user (clear session cookie)
app.post('/api/auth/signout', (req, res) => {
  res.clearCookie('session');
  res.json({ success: true });
});

// Protected endpoint example
app.get('/api/me', (req, res) => {
  const session = req.cookies.session;
  if (!session) return res.status(401).json({ error: 'Not authenticated' });

  try {
    const userData = JSON.parse(session);
    res.json({ user: userData });
  } catch {
    res.status(400).json({ error: 'Invalid session' });
  }
});

// Start server
app.listen(port, () =>
  console.log(`Server running on http://localhost:${port}`)
);
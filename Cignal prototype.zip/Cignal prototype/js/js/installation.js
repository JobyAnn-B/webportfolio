let selectedBox = null;
let selectedPlan = null;

function selectBox(type) {
    selectedBox = type;
    document.getElementById('planSelection').classList.remove('hidden');
    
    // Show appropriate plans based on box type
    if (type === 'SD') {
        document.getElementById('plan300').style.display = 'none';
        document.getElementById('plan200').style.display = 'block';
    } else {
        document.getElementById('plan300').style.display = 'block';
        document.getElementById('plan200').style.display = 'block';
    }
    
    // Scroll to plan selection
    document.getElementById('planSelection').scrollIntoView({ behavior: 'smooth' });
}

function selectPlan(plan) {
    selectedPlan = plan;
    document.getElementById('partnerSelection').classList.remove('hidden');
    document.getElementById('partnerSelection').scrollIntoView({ behavior: 'smooth' });
}

function selectPartner(partner) {
    // Save selection to session storage
    sessionStorage.setItem('installation', JSON.stringify({
        boxType: selectedBox,
        plan: selectedPlan,
        partner: partner
    }));
    
    // Redirect to payment page
    window.location.href = 'payment.html';
}
// Load order details from session storage
document.addEventListener('DOMContentLoaded', () => {
    const installation = JSON.parse(sessionStorage.getItem('installation'));
    loadOrderDetails(installation);
    initializePaymentUI();
});

function loadOrderDetails(installation) {
    if (!installation) {
        window.location.href = 'installation.html';
        return;
    }
    
    document.getElementById('packageType').textContent = installation.boxType + ' Box';
    document.getElementById('planDetails').textContent = `Load ${installation.plan}`;
    document.getElementById('totalAmount').textContent = `₱${installation.plan}`;
    
    // Add animation to summary
    const summary = document.querySelector('.payment-summary');
    summary.classList.add('fade-in');
}

function initializePaymentUI() {
    const paymentOptions = document.querySelectorAll('.payment-option');
    const loadingSpinner = document.createElement('div');
    loadingSpinner.className = 'loading-spinner hidden';
    document.body.appendChild(loadingSpinner);

    paymentOptions.forEach(option => {
        option.addEventListener('click', () => selectPayment(option.dataset.method));
    });
}

function selectPayment(method) {
    selectedPaymentMethod = method;
    
    // Update UI
    document.querySelectorAll('.payment-option').forEach(option => {
        option.classList.remove('selected');
        if (option.dataset.method === method) {
            option.classList.add('selected');
            option.classList.add('pulse-animation');
        }
    });

    // Show form with animation
    const paymentForm = document.getElementById('paymentForm');
    paymentForm.classList.remove('hidden');
    paymentForm.classList.add('slide-up');
}

document.getElementById('processPayment').addEventListener('submit', async (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    const submitButton = e.target.querySelector('button[type="submit"]');
    
    try {
        // Show loading state
        submitButton.disabled = true;
        submitButton.innerHTML = '<span class="spinner"></span> Processing...';
        document.querySelector('.loading-spinner').classList.remove('hidden');

        const result = await processPayment({
            method: selectedPaymentMethod,
            accountNumber: formData.get('accountNumber'),
            accountName: formData.get('accountName'),
            amount: document.getElementById('totalAmount').textContent.replace('₱', '')
        });

        // Show success animation
        document.querySelector('.payment-container').classList.add('success-animation');
        
        // Store transaction details
        sessionStorage.setItem('lastTransaction', JSON.stringify({
            id: result.transactionId,
            date: new Date().toISOString(),
            amount: document.getElementById('totalAmount').textContent,
            status: 'success'
        }));

        // Redirect with animation
        setTimeout(() => {
            window.location.href = 'payment-success.html';
        }, 1500);

    } catch (error) {
        // Show error notification
        showNotification('Payment failed. Please try again.', 'error');
        submitButton.disabled = false;
        submitButton.textContent = 'Try Again';
    } finally {
        document.querySelector('.loading-spinner').classList.add('hidden');
    }
});

function showNotification(message, type) {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    document.body.appendChild(notification);

    setTimeout(() => {
        notification.classList.add('show');
        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => notification.remove(), 300);
        }, 3000);
    }, 100);
}

async function processPayment(paymentDetails) {
    // Simulate API call with better error handling
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            if (Math.random() > 0.1) { // 90% success rate
                resolve({
                    success: true,
                    transactionId: 'TXN' + Math.random().toString(36).substr(2, 9),
                    timestamp: new Date().toISOString()
                });
            } else {
                reject(new Error('Payment processing failed'));
            }
        }, 2000);
    });
}
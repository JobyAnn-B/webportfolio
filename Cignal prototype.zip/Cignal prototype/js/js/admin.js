// Initialize sales chart
const salesChart = new Chart(document.getElementById('salesChart'), {
    type: 'line',
    data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
        datasets: [{
            label: 'Sales',
            data: [12000, 19000, 15000, 25000, 22000, 30000],
            borderColor: '#e31837',
            tension: 0.4
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: {
                position: 'top',
            }
        }
    }
});

// Load recent transactions
const transactions = [
    { id: '1234', user: 'John Doe', amount: '₱200', date: '2024-01-20', status: 'completed' },
    { id: '1235', user: 'Jane Smith', amount: '₱300', date: '2024-01-20', status: 'pending' },
    // Add more transaction data
];

function loadTransactions() {
    const transactionList = document.querySelector('.transaction-list');
    transactions.forEach(transaction => {
        const item = document.createElement('div');
        item.className = 'transaction-item';
        item.innerHTML = `
            <div class="transaction-info">
                <strong>${transaction.user}</strong>
                <span>${transaction.amount}</span>
            </div>
            <div class="transaction-meta">
                <span>${transaction.date}</span>
                <span class="status ${transaction.status}">${transaction.status}</span>
            </div>
        `;
        transactionList.appendChild(item);
    });
}

// Initialize dashboard
document.addEventListener('DOMContentLoaded', () => {
    loadTransactions();
});
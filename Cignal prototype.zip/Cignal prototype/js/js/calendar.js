document.addEventListener('DOMContentLoaded', function() {
    const calendarEl = document.getElementById('calendar');
    const calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        headerToolbar: {
            left: 'prev,next today',
            center: 'title',
            right: 'dayGridMonth,timeGridWeek,timeGridDay'
        },
        events: [
            // Sample events
            {
                title: 'HD Installation - John Doe',
                start: '2024-01-22T08:00:00',
                end: '2024-01-22T12:00:00',
                backgroundColor: '#e31837'
            }
        ],
        eventClick: function(info) {
            // Show event details
            alert(info.event.title);
        }
    });
    calendar.render();
});

// Modal handling
const modal = document.getElementById('scheduleModal');
const closeBtn = document.querySelector('.close');

function openScheduleModal() {
    modal.style.display = 'block';
}

closeBtn.onclick = function() {
    modal.style.display = 'none';
}

window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = 'none';
    }
}

// Form handling
document.getElementById('scheduleForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const formData = new FormData(this);
    
    // Create event object
    const event = {
        title: `${formData.get('type').toUpperCase()} Installation - ${formData.get('customerName')}`,
        start: `${formData.get('installDate')}T${formData.get('timeSlot') === 'morning' ? '08:00:00' : '13:00:00'}`,
        end: `${formData.get('installDate')}T${formData.get('timeSlot') === 'morning' ? '12:00:00' : '17:00:00'}`,
        backgroundColor: '#e31837',
        extendedProps: {
            address: formData.get('address')
        }
    };

    // Add event to calendar
    calendar.addEvent(event);
    modal.style.display = 'none';
    this.reset();
});